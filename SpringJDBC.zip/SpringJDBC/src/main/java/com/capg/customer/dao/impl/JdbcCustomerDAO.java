package com.capg.customer.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.capg.customer.dao.CustomerDAO;
import com.capg.customer.model.User;

public class JdbcCustomerDAO implements CustomerDAO
{
	private DataSource dataSource;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public void insert(User user){
		
		String sql = "INSERT INTO D_USER " +
				"(USERID,LASTNAME,FIRSTNAME,ADDRESS,CITY) VALUES (?, ?, ?,?,?)";
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, user.getUserId());
			ps.setString(2,user.getLastNAme());
			ps.setString(3, user.getFirstNAme());
			ps.setString(4, user.getAddress());
			ps.setString(5, user.getCity());
			ps.executeUpdate();
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	public User findByCustomerId(String UserId){
		
		String sql = "SELECT * FROM CUSTOMER WHERE USERID = ?";
		
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, UserId);
			User user = null;
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user = new User(
						rs.getString("USERID"),
						rs.getString("LASTNAME"),
						rs.getString("FIRSTNAME"), 
						rs.getString("ADDRESS"), 
						rs.getString("CITY") 
						
				);
			}
			rs.close();
			ps.close();
			return user;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}
}




