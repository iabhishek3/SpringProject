package com.capg.customer.model;

public class User 
{
	
String UserId;
String FirstNAme;
String LastNAme;
String Address;
String City;
public String getUserId() {
	return UserId;
}
public void setUserId(String userId) {
	UserId = userId;
}
public String getFirstNAme() {
	return FirstNAme;
}
public void setFirstNAme(String firstNAme) {
	FirstNAme = firstNAme;
}
public String getLastNAme() {
	return LastNAme;
}
public void setLastNAme(String lastNAme) {
	LastNAme = lastNAme;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
public User(String userId, String firstNAme, String lastNAme, String address, String city) {
	super();
	UserId = userId;
	FirstNAme = firstNAme;
	LastNAme = lastNAme;
	Address = address;
	City = city;
}
@Override
public String toString() {
	return "User [UserId=" + UserId + ", FirstNAme=" + FirstNAme + ", LastNAme=" + LastNAme + ", Address=" + Address
			+ ", City=" + City + "]";
}
}
