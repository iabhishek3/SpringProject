package com.capg.customer.dao;

import com.capg.customer.model.User;

public interface CustomerDAO 
{
	public void insert(User user);
	public User findByCustomerId(String UserID);
}




