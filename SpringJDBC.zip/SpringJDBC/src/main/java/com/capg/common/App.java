package com.capg.common;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capg.customer.dao.CustomerDAO;
import com.capg.customer.model.User;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("Spring-Module.xml");
    	 
        CustomerDAO customerDAO = (CustomerDAO) context.getBean("customerDAO");
        User customer = new User("111","kumar","abhishek","Blr","blr");
        customerDAO.insert(customer);
    	
       // User customer1 = customerDAO.findByCustomerId("");
       // System.out.println(customer1);
        
    }
}
